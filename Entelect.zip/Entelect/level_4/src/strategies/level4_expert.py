"""
Level 4 Expert Strategy - "Centroid-Buffered Five-Stripe Partitioning"
Tailored specifically for Level 4 "Forest" (200x300 grid, 800 ticks, 6,413 cells).

Strategy Mechanics:
1. Habitable cell filtering: Starters thrive on Soil 0 (Dirt) & Soil 1 (Mud) -> 5,406 cells.
2. Vertical Stripe Partitioning (5 Stripes):
   - Stripe 0 (cols 4-38): Oak Tree (Index 12) - Moore r=2 spreader.
   - Stripe 1 (cols 38-59): Rose Bush (Index 2) - Non-spreader in Winter.
   - Stripe 2 (cols 59-93): Dwarf Sunflower (Index 5) - CrossHatch r=2 spreader.
   - Stripe 3 (cols 93-210): Lavender (Index 6) - Non-spreader in Winter.
   - Stripe 4 (cols 211-299): Grass (Index 1) - VonNeumann r=1 spreader.
3. Centroid Seed Selection:
   - Spreading seeds (Oak, Sunflower, Grass) are selected from the interior centroids of their zones,
     buffered away from the shared borders with Rose Bush and Lavender.
4. Timed Phased Deployment:
   - Oak Tree seeds deployed at tick 701 (80 seeds).
   - Grass seeds deployed at tick 705 (100 seeds).
   - Rose Bush deployed at tick 710 (direct planting).
   - Lavender deployed at tick 740 (direct planting).
   - Dwarf Sunflower seeds deployed at tick 746 (60 seeds) for controlled expansion.
5. Starvation Immunity:
   - All actions take place between tick 701 and 799 (last 99 ticks), guaranteeing 0 starvation deaths.
"""

from typing import List, Dict, Any, Tuple, Optional
from core.models import LevelConfig, Submission, PlantAction, TickEntry
from core.loader import ResourceLoader
from strategies.base import BaseStrategy


class Level4ExpertStrategy(BaseStrategy):
    def __init__(self, config: Optional[LevelConfig] = None, loader: Optional[ResourceLoader] = None):
        super().__init__()
        self.config = config
        self.loader = loader

    def solve(self) -> Submission:
        if self.config is None:
            raise ValueError("Config not provided to Level4ExpertStrategy")
        return self.generate_submission(self.config, self.loader)

    def generate_submission(self, config: LevelConfig, loader: Optional[ResourceLoader] = None) -> Submission:
        # 1. Identify all habitable cells for starter plants (soil 0 or 1)
        hab_coords = sorted(
            [coord for coord, cell in config.cells.items() if cell.soil in (0, 1)],
            key=lambda rc: (rc[1], rc[0])
        )
        total = len(hab_coords)
        zone_size = total // 5

        # 2. Divide into 5 vertical stripes
        zones = {
            12: hab_coords[0 : zone_size],             # cols 4-38
            2:  hab_coords[zone_size : 2 * zone_size], # cols 38-59
            5:  hab_coords[2 * zone_size : 3 * zone_size], # cols 59-93
            6:  hab_coords[3 * zone_size : 4 * zone_size], # cols 93-210
            1:  hab_coords[4 * zone_size : ]           # cols 211-299
        }

        # 3. Sort coordinates by proximity to zone interior centroid
        oak_sorted = sorted(zones[12], key=lambda rc: abs(rc[1] - 20))
        sun_sorted = sorted(zones[5], key=lambda rc: abs(rc[1] - 76))
        grass_sorted = sorted(zones[1], key=lambda rc: abs(rc[1] - 255))
        rose_sorted = sorted(zones[2], key=lambda rc: abs(rc[1] - 48))
        lav_sorted = sorted(zones[6], key=lambda rc: abs(rc[1] - 150))

        def pick_seeds(sorted_coords: List[Tuple[int, int]], n_seeds: int) -> List[Tuple[int, int]]:
            pool = sorted_coords[:len(sorted_coords) * 3 // 4]
            step = len(pool) / float(n_seeds)
            return [pool[int(i * step)] for i in range(n_seeds)]

        # Optimal fine-tuned parameters (Yields 738,127,173 pts)
        sun_tick, sun_n, oak_n, grass_n = 749, 60, 85, 105
        rem = 1980 - (oak_n + sun_n + grass_n)
        rose_cnt = rem // 2
        lav_cnt = rem - rose_cnt

        oak_seeds = pick_seeds(oak_sorted, oak_n)
        sun_seeds = pick_seeds(sun_sorted, sun_n)
        grass_seeds = pick_seeds(grass_sorted, grass_n)
        rose_seeds = rose_sorted[:rose_cnt]
        lav_seeds = lav_sorted[:lav_cnt]

        # 4. Schedule actions respecting max 20 plants/tick limit
        actions_by_tick: Dict[int, List[PlantAction]] = {}

        def add_plants(t_start: int, seeds: List[Tuple[int, int]], p_idx: int):
            t = t_start
            idx = 0
            while idx < len(seeds):
                while t in actions_by_tick and len(actions_by_tick[t]) >= 20:
                    t += 1
                current_count = len(actions_by_tick.get(t, []))
                take = min(20 - current_count, len(seeds) - idx)
                batch = [PlantAction(row=r, col=c, plant_index=p_idx) for r, c in seeds[idx : idx + take]]
                actions_by_tick.setdefault(t, []).extend(batch)
                idx += take
                if len(actions_by_tick[t]) >= 20:
                    t += 1

        add_plants(701, oak_seeds, 12)
        add_plants(705, grass_seeds, 1)
        add_plants(sun_tick, sun_seeds, 5)
        add_plants(710, rose_seeds, 2)
        add_plants(740, lav_seeds, 6)

        tick_entries = [
            TickEntry(tick=t, plants=actions_by_tick[t])
            for t in sorted(actions_by_tick.keys())
            if t < config.ticks
        ]

        return Submission(actions=tick_entries)
