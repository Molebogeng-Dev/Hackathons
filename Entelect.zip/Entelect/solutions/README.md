# Entelect Hackathon: Solutions Hub

This directory contains all finalized submission files for Levels 1, 2, 3, and 4, organized and named for clean drag-and-drop submission to the competition portal.

---

## Submission Files Overview

| Level | Portal Upload: ZIP File | Portal Upload: JSON File | Standalone Leaderboard Score |
| :--- | :--- | :--- | :--- |
| **Level 1** | `level_1_solution.zip` | `level_1_solution.json` | **801,631,386 pts** |
| **Level 2** | `level_2_solution.zip` | `level_2_solution.json` | **802,133,259 pts** |
| **Level 3** | `level_3_solution.zip` | `level_3_solution.json` | **765,342,469 pts** |
| **Level 4** | `level_4_solution.zip` | `level_4_solution.json` | **738,127,173 pts** |
| **COMBINED TOTAL** | — | — | **★ 3,107,234,287 pts** |

**Target (4 Billion Points)**: **77.68% achieved** (> 3.107 Billion points).

---

## How to Submit on the Portal

For each level on the competition portal:
1. Under **"Upload ZIP File"**, drag and drop `level_X_solution.zip`.
2. Under **"Upload JSON File"**, drag and drop `level_X_solution.json`.
3. Click **"SUBMIT SOLUTION"**.

All JSON files contain dual keys (`"plant_index"` and `"index"`) ensuring bulletproof validator acceptance.

---

## Archive Details
Each `.zip` archive is fully self-contained with:
- `run.py` (CLI solver and scoring evaluator)
- `src/core/` (simulation engine, geometry, models, loader, condition evaluator)
- `src/strategies/` (expert planting strategies)
- `additional-resources/` (encyclopedias, animals, classifications, unlocks)
- Map files (`1.json`, `2.json`, `3.json`, `4.json`)
- Verified `solution.json`
